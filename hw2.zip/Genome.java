/**
 * Author: Alex Orozco
 * Assignment 2 : Evolving Names
 */
import java.util.Random;

public class Genome {
	private String currentString;
	private String potential[] = { "A", "B", "C", "D", "E", "F", "G", "H", 
			"I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", 
			"T","U", "V", "W", "X", "Y", "Z", "_", "�", "�" };
	private Integer fitness;
	private double mutationRatio;
	private String target = "CHRISTOPHER_PAUL_MARRIOTT";
	public Genome(Genome gene)
	{
		fitness = gene.fitness();
		mutationRatio = gene.mutationRatio;
		currentString = gene.currentString;
	}
	public Genome(double mutationRate)
	{
		currentString = "A";
		mutationRatio = mutationRate;
	}
	void mutate()
	{
		Random rand = new Random();
		StringBuilder temp;
		temp = new StringBuilder(this.currentString);
		double randomNum = Math.random();
		if(randomNum <= this.mutationRatio) //add a random element
		{
			if(this.currentString.length() == 0)
				temp.insert(rand.nextInt(this.currentString.length()+1),potential[rand.nextInt(potential.length)].charAt(0));
			else
				temp.insert(rand.nextInt(this.currentString.length()),potential[rand.nextInt(potential.length)].charAt(0));
		}	
		double randomNum2 = Math.random();
		if(randomNum2 <= this.mutationRatio && this.currentString.length() >= 2 ) //delete a random char
		{
			temp.deleteCharAt(rand.nextInt(temp.length()));	
		}
		for(int i = 0; i < temp.length(); i++) //o(n)
		{
			randomNum = Math.random();
			if(randomNum <= this.mutationRatio) //mutate each char
			{
				temp.setCharAt(i, potential[rand.nextInt(potential.length)].charAt(0));
			}
		}
		this.currentString = temp.toString();
	}
	void crossover(Genome other)
	{
		StringBuilder temp = new StringBuilder();
		String parentString = other.currentString;
		int bounds;
		if(parentString.length() > currentString.length()) //find the longer string
			bounds = parentString.length();
		else
			bounds = currentString.length();
		  
		Random rand =  new Random();
		for(int i =0; i < bounds; i++)
		{
			int decision = rand.nextInt(2); //randomly choose 1 of two parents
			if(decision == 0)
			{
				if(parentString.length() < bounds) //if we select one of the parents with a shorter string, we must break.
				{
					break;
				}
				temp.append(parentString.charAt(i));
			}
			else
			{
				if(currentString.length() < bounds) //if we select one of the parents with a shorter string, we must break.
				{
					break;
				}
				temp.append(currentString.charAt(i));
			}
		}
		currentString = temp.toString();
	}
	Integer fitnesssss() //the boring implementation
	{
		int temp = target.length() - currentString.length();
		for( int i = 0; i < target.length(); i++)
		{
			if(i > currentString.length()-1 || currentString.charAt(i) != target.charAt(i))
			{
				temp++;
			}
		}
		fitness = new Integer(temp);
		return fitness;
	}
	Integer fitness()
	{
		if(currentString.length() == 0)
		{
			return this.fitnesssss();
		}
		int num1 = target.length();
		int num2 = currentString.length();
		int[][] arr = new int[num1+1][num2+1];
		int tempVal1;
		int tempVal2;
		for (int i = 0; i <= num2; i++) {
		    arr[0][i] = i;
		}
		for (int j = 0; j <= num1; j++) {
		    arr[j][0] = j;
		}
		for( int i = 0; i < num1; i++)
		{
			for(int j = 0; j < num2; j++)
			{
				tempVal1 = (target.charAt(i) == currentString.charAt(j)) ? 0:1;
				tempVal2 = Math.min(arr[i][j + 1] + 1, arr[i + 1][j] + 1);
				arr[i + 1][j + 1] = Math.min(tempVal2, arr[i][j] + tempVal1);
			}
		}
		fitness = new Integer(arr[num1][num2]);
		return fitness;
	}
	public String toString()
	{
		StringBuilder temp = new StringBuilder();
		temp.append("(\"" + currentString + "\", " + this.fitness().toString() + ")");
		for(int i = 0; i < temp.length(); i++)
			if(temp.charAt(i) == '_')
				temp.setCharAt(i,' ');
		return temp.toString();
	}
}
