/**
 * Author: Alex Orozco
 * Assignment 2 : Evolving Names
 */
import java.io.IOException;

public class Main {
	 private Main() {
	        throw new IllegalStateException();
	 }
	 public static void main(final String[] theArgs) throws IOException
	{
		// testGenome();
		// testPopulation();
		Population thePop = new Population(100, .05);
		long startTime = System.currentTimeMillis();
		int generations = 0;
		while(thePop.mostFit.fitness() > 0)
		{
			thePop.mostFitInfo();
			thePop.day();
			generations++;
		}
		thePop.mostFitInfo();
		long endTime = System.currentTimeMillis();
		System.out.println("Generations: " + Integer.toString(generations));
		System.out.println("Run Time: " + Long.toString(endTime - startTime) +" milliseconds");
	}
	static void testGenome()
	{
		Genome temp = new Genome(.05);
		Genome clone = new Genome(temp);
		boolean cloneWorks = clone.equals(temp);
		System.out.println("Cloned: " + cloneWorks);
		printInfo("Init", temp,clone);
		temp.mutate();
		printInfo("Mutatte Origin", temp,clone);
		clone.mutate();
		printInfo("Mutate Clone", temp,clone);
		temp.crossover(clone);
		printInfo("Original cross Over", temp,clone);
		clone.crossover(temp);
		printInfo("Clone cross Over", temp,clone);
		
	}
	private static void printInfo(String action, Genome g1, Genome g2)
	{
		System.out.println(action);
		System.out.println("Original: " +g1.toString());
		System.out.println("Clone: " +g2.toString());
	}
	static void testPopulation()
	{
		Population thePop = new Population(10, .05);
		thePop.populationInfo();
		for(int i = 0; i < 5; i ++)
		{
			thePop.day();
			System.out.print("Most Fit:");
			thePop.mostFitInfo();
			System.out.print("General Population:");
			thePop.populationInfo();
		}
	}
}
