/**
 * Author: Alex Orozco
 * Assignment 2 : Evolving Names
 */
import java.util.Random;

public class Population {
	private Genome[] genomList;
	public Genome mostFit;
	public String target;
	public Population(Integer numGenomes, Double mutationRate)
	{
		target = "CHRISTOPHER PAUL MARRIOTT";
		genomList = new Genome[numGenomes];
		for( int i = 0; i < numGenomes.intValue(); i++)
		{
			genomList[i] = new Genome(mutationRate);
		}
		mostFit = genomList[0];
	}
	public void day()
	{
		this.cocktailSortGenom(); 
		mostFit = genomList[0];
		Random rand = new Random(); 
		for(int i = genomList.length/2; i < genomList.length; i++)
		{
			if(rand.nextInt() % 2 == 0)
			{
				genomList[i] = new Genome(genomList[rand.nextInt(genomList.length/2)]); //the list will always be sorted so adding new
				genomList[i].mutate();
			}
			else 
			{
				genomList[i] = new Genome(genomList[rand.nextInt(genomList.length/2)]); //the list will always be sorted so adding new 
				genomList[i].crossover(genomList[rand.nextInt(genomList.length/2)]);
				genomList[i].mutate();
			}
		}
	}
	public void mostFitInfo()
	{
		System.out.println(mostFit.toString());
	}
	public void populationInfo()
	{
		for( Genome i: genomList)
		{
			System.out.println(i.toString());
		}
	}
	private void cocktailSortGenom() //bubble sort forwards and backwards.
	{
		boolean swapped = true;
		int i = 0;
		int j = genomList.length - 1;
		while( i < j && swapped)
		{
			swapped = false;
			for(int k = i; k < j; k++)
			{
				if(genomList[k].fitness() > genomList[k+1].fitness())
				{
					Genome temp = genomList[k];
					genomList[k] = genomList[k+1];
					genomList[k+1] = temp;
					swapped  = true;
				}
			}
			j--;
			if(swapped)
			{
				swapped = false;
				for(int k = j; k > i; k--)
				{
					if(genomList[k].fitness() < genomList[k-1].fitness())
					{
						Genome temp = genomList[k];
						genomList[k] = genomList[k-1];
						genomList[k-1] = temp;
						swapped  = true;
					}
				}
			}
			i++;
		}
	}
}
